package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class StoreActivity extends AppCompatActivity {

    Button contButton;

    Products item1 = new Products("Apple", 3.99, 2.99, 4.49);
    Products item2 = new Products("Peach", 4.99, 6.09, 2.99);
    Products item3 = new Products("Chicken Wings", 9.99, 12.99, 13.99);
    Products item4 = new Products("Maple Syrup", 5.00, 3.67, 8.99);
    Products item5 = new Products("Ground Beef", 5.99, 5.99, 4.49);
    Products item6 = new Products("Corn", 1.99, 1.49, 0.99);
    Products item7 = new Products("Milk", 4.99, 3.99, 5.99);
    Products item8 = new Products("Orange Juice", 6.99, 4.99, 5.49);
    Products item9 = new Products("Vanilla Ice Cream", 7.99, 6.99, 5.49);
    Products item10 = new Products("Ketchup", 1.99, 1.99, 0.99);
    Products item11 = new Products("Frozen Pizza", 10.99, 8.99, 9.49);
    Products item12 = new Products("Noodles", 2.99, 3.99, 3.99);
    Products item13 = new Products("Pasta Sauce", 3.99, 6.99, 5.99);
    Products item14 = new Products("Taco Seasoning", 0.99, 0.49, 1.99);
    Products item15 = new Products("Can of Beans", 7.99, 5.99, 3.99);
    Products item16 = new Products("Pork Shoulder", 12.99, 11.99, 19.99);
    Products item17 = new Products("Birthday Cake Mix", 2.99, 6.99, 4.99);
    Products item18 = new Products("Cheese", 8.99, 3.99, 5.99);
    Products item19 = new Products("Goldfish", 4.99, 2.99, 2.99);
    Products item20 = new Products("Olive Oil", 6.99, 7.99, 5.99);

    ArrayList<Products> shoppingList = new ArrayList<Products>();
    ArrayList<String> productName = new ArrayList<String>();


    public ListView shopView;
    public ArrayList<Object> addedItems = new ArrayList<Object>();
    public ArrayList<Double> addedPrice1 = new ArrayList<Double>();
    public ArrayList<Double> addedPrice2 = new ArrayList<Double>();
    public ArrayList<Double> addedPrice3 = new ArrayList<Double>();


    //private Object List;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);


        shoppingList.add(item1);
        shoppingList.add(item2);
        shoppingList.add(item3);
        shoppingList.add(item4);
        shoppingList.add(item5);
        shoppingList.add(item6);
        shoppingList.add(item7);
        shoppingList.add(item8);
        shoppingList.add(item9);
        shoppingList.add(item10);
        shoppingList.add(item11);
        shoppingList.add(item12);
        shoppingList.add(item13);
        shoppingList.add(item14);
        shoppingList.add(item15);
        shoppingList.add(item16);
        shoppingList.add(item17);
        shoppingList.add(item18);
        shoppingList.add(item19);
        shoppingList.add(item20);

        productName.add(item1.getName());
        productName.add(item2.getName());
        productName.add(item3.getName());
        productName.add(item4.getName());
        productName.add(item5.getName());
        productName.add(item6.getName());
        productName.add(item7.getName());
        productName.add(item8.getName());
        productName.add(item9.getName());
        productName.add(item10.getName());
        productName.add(item11.getName());
        productName.add(item12.getName());
        productName.add(item13.getName());
        productName.add(item14.getName());
        productName.add(item15.getName());
        productName.add(item16.getName());
        productName.add(item17.getName());
        productName.add(item18.getName());
        productName.add(item19.getName());
        productName.add(item20.getName());

//        Intent intent = new Intent(getBaseContext(), MainActivity.class);
//        intent.putExtra("addedItems",addedItems);
//        startActivity(intent);


        shopView = (ListView) findViewById(R.id.shoppingList);

        //ArrayList<String> li = (ArrayList<String>) getIntent().getSerializableExtra("productName");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, productName);
        shopView.setAdapter(arrayAdapter);

        shopView = findViewById(R.id.shoppingList);
        shopView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                shopView = (ListView) findViewById(R.id.shoppingList);
                String clickedItem = (String) parent.getItemAtPosition(position);
                Toast.makeText(getApplicationContext(), "Added " + clickedItem + " To the Cart", Toast.LENGTH_SHORT).show();
                addedItems.add(parent.getItemAtPosition(position));
                System.out.println(addedItems);
                addedPrice1.add(shoppingList.get(position).getPriceOne());
                System.out.println(addedPrice1);
                addedPrice2.add(shoppingList.get(position).getPriceTwo());
                addedPrice3.add(shoppingList.get(position).getPriceThree());


            }
        });


        contButton = findViewById(R.id.continueButton);
        contButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println(addedItems);

                Intent intent = new Intent(StoreActivity.this, MainActivity.class);
                intent.putExtra("addedItems",addedItems);
                //startActivity(intent);

//                Intent intent2 = new Intent(StoreActivity.this, MainActivity.class);
                intent.putExtra("addedPrice1",addedPrice1);
                //startActivity(intent);

//                Intent intent3 = new Intent(getBaseContext(), MainActivity.class);
                intent.putExtra("addedPrice2",addedPrice2);
                //startActivity(intent);
//
//                Intent intent4 = new Intent(getBaseContext(), MainActivity.class);
                intent.putExtra("addedPrice3",addedPrice3);
                startActivity(intent);

//                Intent i = new Intent(StoreActivity.this, MainActivity.class);
//                startActivity(i);


            }
        });
    }
}
