package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {



//    Products item1 = new Products("Apple", 3.99, 2.99, 4.49);
//    Products item2 = new Products("Peach", 4.99, 6.09, 2.99);
//    Products item3 = new Products("Chicken Wings", 9.99, 12.99, 13.99);
//    Products item4 = new Products("Maple Syrup", 5.00, 3.67, 8.99);
//    Products item5 = new Products("Ground Beef", 5.99, 5.99, 4.49);
//    Products item6 = new Products("Corn", 1.99, 1.49, 0.99);
//    Products item7 = new Products("Milk", 4.99, 3.99, 5.99);
//    Products item8 = new Products("Orange Juice", 6.99, 4.99, 5.49);
//    Products item9 = new Products("Vanilla Ice Cream", 7.99, 6.99, 5.49);
//    Products item10 = new Products("Ketchup", 1.99, 1.99, 0.99);
//    Products item11 = new Products("Frozen Pizza", 10.99, 8.99, 9.49);
//    Products item12 = new Products("Noodles", 2.99, 3.99, 3.99);
//    Products item13 = new Products("Pasta Sauce", 3.99, 6.99, 5.99);
//    Products item14 = new Products("Taco Seasoning", 0.99, 0.49, 1.99);
//    Products item15 = new Products("Can of Beans", 7.99, 5.99, 3.99);
//    Products item16 = new Products("Pork Shoulder", 12.99, 11.99, 19.99);
//    Products item17 = new Products("Birthday Cake Mix", 2.99, 6.99, 4.99);
//    Products item18 = new Products("Cheese", 8.99, 3.99, 5.99);
//    Products item19 = new Products("Goldfish", 4.99, 2.99, 2.99);
//    Products item20 = new Products("Olive Oil", 6.99, 7.99, 5.99);
//
//    ArrayList<Products> shoppingList = new ArrayList<Products>();
//    ArrayList<String> productName = new ArrayList<String>();

    Button b1  ;
    Button mButton;

    public ListView li1, li2, li3, li4;

    public double total1 = 0, total2 = 0, total3 = 0;

    public TextView tv1, tv2, tv3;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        li1 = (ListView) findViewById(R.id.list_one);
        li2 = (ListView) findViewById(R.id.list_two);
        li3 = (ListView) findViewById(R.id.list_three);
        li4 = (ListView) findViewById(R.id.list_four);

        tv1 = (TextView) findViewById(R.id.totalOne);
        tv2 = (TextView) findViewById(R.id.totalTwo);
        tv3 = (TextView) findViewById(R.id.totalThree);







        ArrayList<String> listName = (ArrayList<String>) getIntent().getSerializableExtra("addedItems");

        ArrayList<Double> listPriceTwo = (ArrayList<Double>) getIntent().getSerializableExtra("addedPrice1");

        ArrayList<Double> listPriceThree = (ArrayList<Double>) getIntent().getSerializableExtra("addedPrice2");

        ArrayList<Double> listPriceTwoFour = (ArrayList<Double>) getIntent().getSerializableExtra("addedPrice3");

        System.out.println(listName);
        System.out.println(listPriceTwo);
        ArrayAdapter<Double> arrayAdapter = new ArrayAdapter<Double>(this, android.R.layout.simple_list_item_1, listPriceTwo);
        li2.setAdapter(arrayAdapter);

        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listName);
        li1.setAdapter(arrayAdapter2);

        ArrayAdapter<Double> arrayAdapter3 = new ArrayAdapter<Double>(this, android.R.layout.simple_list_item_1, listPriceThree);
        li3.setAdapter(arrayAdapter3);

        ArrayAdapter<Double> arrayAdapter4 = new ArrayAdapter<Double>(this, android.R.layout.simple_list_item_1, listPriceTwoFour);
        li4.setAdapter(arrayAdapter4);


        for (double num : listPriceTwo){
            total1 += num;

        }
        for (double num : listPriceThree){
            total2 += num;

        }
        for (double num : listPriceTwoFour){
            total3 += num;

        }

        tv1.setText(String.format("%.2f", total1));
        tv2.setText(String.format("%.2f", total2));
        tv3.setText(String.format("%.2f", total3));

        if (total1 >= total2 && total1 >= total3 && total2 >= total3) {

            tv1.setBackgroundColor(Color.RED);
            tv2.setBackgroundColor(Color.YELLOW);
            tv3.setBackgroundColor(Color.GREEN);
        }
        else if (total2 >= total1 && total2 >= total3 && total3 >= total1){

            tv1.setBackgroundColor(Color.GREEN);
            tv2.setBackgroundColor(Color.RED);
            tv3.setBackgroundColor(Color.YELLOW);


        }
        else{
            tv1.setBackgroundColor(Color.YELLOW);
            tv2.setBackgroundColor(Color.GREEN);
            tv3.setBackgroundColor(Color.RED);

        }



//        Intent intent = new Intent(getBaseContext(), StoreActivity.class);
//        intent.putExtra("productName",productName);
//        startActivity(intent);


        //ArrayList<String> li = (ArrayList<String>) getIntent().getSerializableExtra("addedItems");

//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, li);
//        li1.setAdapter(arrayAdapter);


//        b1 = findViewById(R.id.shoppingButton);
//        b1.setOnClickListener(
//                new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//
//                        mButton = (Button) findViewById(R.id.shoppingButton);
//                        Intent j = new Intent(MainActivity.this, StoreActivity.class);
//                        startActivity(j);




    //}


//});
    }
}

