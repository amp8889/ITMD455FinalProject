package com.example.finalproject;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class LoginActivity extends AppCompatActivity {
    Button b1  ;

    Button   mButton;

    EditText firstName, lastName, email, phoneNumber, userName, password;

    FirebaseDatabase rootNode;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        firstName = findViewById(R.id.editFirstName);
        lastName = findViewById(R.id.editLastName);
        email = findViewById(R.id.editEmail);
        phoneNumber = findViewById(R.id.editPhone);
        userName = findViewById(R.id.editUsername);
        password = findViewById(R.id.editPassword);



        b1 = findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    mButton = (Button)findViewById(R.id.button);

                    rootNode = FirebaseDatabase.getInstance();
                    reference = rootNode.getReference("users");

                    String fName = firstName.getEditableText().toString();
                    String lName = lastName.getEditableText().toString();
                    String em = email.getEditableText().toString();
                    String ph = phoneNumber.getEditableText().toString();
                    String un = userName.getEditableText().toString();
                    String pass = password.getEditableText().toString();



                    UserHelper userHelper = new UserHelper(fName, lName, em, ph, un, pass);

                    reference.child(ph).setValue(userHelper);


                    Intent i = new Intent(LoginActivity.this, StoreActivity.class);
                    startActivity(i);
                    }






                });
    }
}















