package com.example.finalproject;
import java.io.Serializable;

public class Products implements Serializable {

    private String name;
    private double priceOne, priceTwo, priceThree;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPriceOne() {
        return priceOne;
    }

    public void setPriceOne(int priceOne) {
        this.priceOne = priceOne;
    }

    public double getPriceTwo() {
        return priceTwo;
    }

    public void setPriceTwo(int priceTwo) {
        this.priceTwo = priceTwo;
    }

    public double getPriceThree() {
        return priceThree;
    }

    public void setPriceThree(int priceThree) {
        this.priceThree = priceThree;
    }

    public Products(String name, double priceOne, double priceTwo, double priceThree) {

        this.name = name;
        this.priceOne = priceOne;
        this.priceTwo = priceTwo;
        this.priceThree = priceThree;


    }


}
